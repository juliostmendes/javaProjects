package main;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		double[] x = new double[100];
		int n;
		Scanner ler = new Scanner(System.in);
		
		System.out.println("Digite o valor de x0: ");
		x[0] = ler.nextDouble();
		
		System.out.println("Digite o valor de x1: ");
		x[1] = ler.nextDouble();
		
		System.out.println("Digite o número de iterações: ");
		n = ler.nextInt();
		
		System.out.println(metodoSecante(x, n));
		
	}
	
	public static double metodoSecante(double[] x, int n) {
		int j = n;
		int i;
		for(i = 2; i < j; i++) {
			x[i] = x[i-1] - (funcao(x[i-1]))*((x[i-1] - x[i-2])/(funcao(x[i-1]) - funcao(x[i-2])));
		}
		
		return x[j-1];
	}
	
	public static double funcao(double x) {
		//return Math.pow(x, 3) - 2;
		return Math.pow(x, 3) - 10*Math.pow(x,  2) - 400;
	}
	
}